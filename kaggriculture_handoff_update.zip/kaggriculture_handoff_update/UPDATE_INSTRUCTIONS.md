# Kaggriculture 引き継ぎ更新

**GitHubには未反映です。** 接続中のGitHub連携がblob作成を403
`Resource not accessible by integration` で拒否したため、外部への書き込みは完了していません。
これはローカルに適用するための変更一式です。

内容:

- README/current state/layout/index/historyの古い記述を修正。
- GPT-5.6-sol向けの実装優先順位・詳細仕様・評価基準・中止条件。
- G6D01の診断コード・評価結果・固定パネル・hashを確認する再現用セットアップ。
- 既存のagent、E番号のコード、提出物は変更しません。

## Macで適用

ZIPをDownloadsへ保存して展開した場合:

```bash
python3 ~/Downloads/kaggriculture_handoff_update/apply_handoff.py --repo ~/Desktop/Kaggle --check
python3 ~/Downloads/kaggriculture_handoff_update/apply_handoff.py --repo ~/Desktop/Kaggle
```

基準commitは `927f29498363349726e395f7c9479d5c767e849a`。
対象ファイルが後から変わっている場合は停止し、勝手に上書きしません。
その場合は次の担当へこのZIPと現在の差分を渡して統合してください。

このスクリプトはローカル適用だけを行い、commit/pushやネットワーク操作は行いません。
GitHubにも反映する場合は、差分を確認してこの27ファイルをcommit/pushしてください。
別の作業がstagedになっている場合は、混ぜてcommitしないでください。

次のモデルへの開始指示:

> README.md、docs/current_research_state.md、docs/g6_research_handoff_2026-09-19.mdを読み、P0の評価相手拡充とP1の回収・肥料確保の連動実験から進めてください。G6D01と過去E番号は凍結し、採否基準と中止条件を守ってください。

`files/` に更新後の全ファイル、`changes.patch` に差分があります。
原リプレイ3件は以前渡した `kaggriculture_g6_research_kit.zip` にあり、このZIPには重複収録していません。
