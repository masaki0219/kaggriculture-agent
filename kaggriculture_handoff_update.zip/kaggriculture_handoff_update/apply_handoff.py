#!/usr/bin/env python3
"""Verify and apply the prepared handoff patch locally. No commit/push/network."""
import argparse
import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(repo,*args):
    return subprocess.run(['git','-C',str(repo),*args],check=True,text=True,capture_output=True)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo',type=Path,required=True)
    parser.add_argument('--check',action='store_true',help='Validate only; do not apply')
    args=parser.parse_args();repo=args.repo.resolve()
    if Path(git(repo,'rev-parse','--show-toplevel').stdout.strip()).resolve()!=repo:
        raise SystemExit('--repoにはリポジトリのrootを指定してください。')
    m=json.loads((ROOT/'manifest.json').read_text());patch=ROOT/'changes.patch'
    if sha(patch.read_bytes())!=m['patch_sha256']:
        raise SystemExit('パッチの内容が変わっています。元のZIPを展開してください。')
    if all((repo/f['path']).is_file() and sha((repo/f['path']).read_bytes())==f['after_sha256'] for f in m['files']):
        print('この更新はすでに適用されています。');return
    for f in m['files']:
        target=repo/f['path'];before=f['before_sha256']
        if before is None:
            if target.exists():raise SystemExit('新規ファイルが既にあります。上書きせず差分を統合してください: '+f['path'])
        elif not target.is_file() or sha(target.read_bytes())!=before:
            raise SystemExit('基準から変更されています。上書きせず差分を統合してください: '+f['path'])
    git(repo,'apply','--check',str(patch))
    if args.check:
        print('確認完了。27ファイルの更新を適用できます。');return
    git(repo,'apply',str(patch))
    for f in m['files']:
        if sha((repo/f['path']).read_bytes())!=f['after_sha256']:
            raise SystemExit('適用後の内容が一致しません: '+f['path'])
    print('27ファイルを更新しました。commit/pushは実行していません。')
    print('README.md と docs/g6_research_handoff_2026-09-19.md を確認してください。')


if __name__=='__main__':
    try:main()
    except subprocess.CalledProcessError as exc:
        raise SystemExit(exc.stderr or str(exc))
