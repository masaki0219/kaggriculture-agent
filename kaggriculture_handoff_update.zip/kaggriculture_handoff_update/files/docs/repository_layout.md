# Repository layout

| Path | Responsibility |
| --- | --- |
| `experiments/` | Immutable numbered experiment history and legacy v/h series |
| `evaluation/` | Experiment-independent arenas and recorded evaluation output |
| `analysis/` | Diagnostics and one-off research analysis |
| `public_agents/` | External Git submodules; paths and pinned SHAs are unchanged |
| `artifacts/` | Canonical current bundle and byte-preserved submissions/snapshots |
| `archive/` | Superseded bundles, intermediary packages, and retained duplicates |
| `data/` | Downloaded/cache data and dated compressed replay corpora |
| `tools/` | Acquisition, setup, and bundle-maintenance utilities |
| `docs/` | Current project records, cleanup reports, and dated history |

The active elite runtime is `artifacts/bundles/current/`. For E21-E29, each
experiment directory contains its builder/screen/results and a lightweight
`agent.py` forwarding module for the frozen canonical agent in that runtime
bundle. New strategy work must use the next unused E number; do not rewrite an
executed experiment's agent, cache, or result.

## Current entry points — 2026-09-19

| Role | Path |
| --- | --- |
| Current primary source | `candidates/2026-09-19_public/tetsutani_demand-preserving-turn-sale-timing/main.py` |
| Latest diagnosis and frozen pilot | `analysis/g6d01/` |
| Next implementation specification | `docs/g6_research_handoff_2026-09-19.md` |
| Short current state | `docs/current_research_state.md` |
| Historical E21 source | `artifacts/bundles/current/agent_e21_tetsu_market_v23.py` |
| Stopped M-family branch | `experiments/e033_m_family_crop_expansion/` |
| Experiment history | `docs/experiment_run_history.md`, `docs/experiment_index.md` |
| Live-population archive | `data/replays/2026-09-18/live_population.zip` (check the internal manifest timestamp) |
| M-family archive | `data/corpora/2026-09-18/m_family.zip` |

E30-E33 are present. E30-E32 have checked-in fidelity results; E33 has code and a README.
Next new policy logic must use a new, unused E number after inspecting the latest tree.
`analysis/g6d01/runtime/` is generated and ignored; it is not another canonical agent source.
