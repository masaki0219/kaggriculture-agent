#!/usr/bin/env python3
"""Verify canonical reference policy against every recorded own-player action."""
import argparse
import copy
import hashlib
import json
from pathlib import Path
from evaluate_candidate import ROOT,load_policy
from analyze_replays import Attr,attr,load_official
from timing_diagnostic import initial


def verify(path):
    r = json.loads(Path(path).read_text())
    pid = r['info']['TeamNames'].index('masa0219')
    policy = load_policy(ROOT/'tetsu_reference.py')
    game = load_official()
    state = initial(r)
    env = Attr(configuration=attr(r['configuration']),info=attr(r['info']),done=False)
    mismatches = []
    for k in range(1,len(r['steps'])):
        # Reconstruct dict insertion order instead of feeding sorted replay JSON.
        obs = copy.deepcopy(state[pid].observation)
        obs['step'] = k-1
        actual = policy.agent(obs,r['configuration'])
        expected = r['steps'][k][pid]['action']
        if actual != expected:
            mismatches.append({'step':k-1,'actual':actual,'expected':expected})
        for seat in range(2):
            state[seat].observation.step = k-1
            state[seat].action = r['steps'][k][seat]['action']
        game.interpreter(state,env)
        for key in ('farms','market','town'):
            assert state[0].observation[key] == r['steps'][k][0]['observation'][key]
        for seat in range(2):
            assert state[seat].observation.private == r['steps'][k][seat]['observation']['private']
    return {'episode':r['info']['EpisodeId'],'actions_checked':len(r['steps'])-1,
            'canonical_agent_mismatch_count':len(mismatches),'mismatches':mismatches}


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('inputs',nargs='+')
    p.add_argument('--out',type=Path,required=True)
    args = p.parse_args()
    results = [verify(path) for path in args.inputs]
    out = {'reference_sha256':hashlib.sha256((ROOT/'tetsu_reference.py').read_bytes()).hexdigest(),
           'episodes':results}
    args.out.write_text(json.dumps(out,indent=2))
    print(json.dumps([{k:v for k,v in r.items() if k!='mismatches'} for r in results]))
    if any(r['canonical_agent_mismatch_count'] for r in results):
        raise SystemExit('Reference mismatch: inspect before attributing results to this source')
