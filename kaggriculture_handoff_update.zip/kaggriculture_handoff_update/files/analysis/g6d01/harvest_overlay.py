"""G6D01 research candidate: value the next dawn's animal overflow explicitly.

Append this source to tetsu_reference.py to build a single-file candidate.
No episode identifiers, future shops, or private opponent state are consulted.
This is a falsifiable production experiment, not a validated submission.
"""
_G6_PARENT = agent
_G6_STATS = {'changes': 0, 'predicted_saved_units': 0, 'errors': 0}


def _g6_harvest_later_today(obs, action, target):
    """Conservative native-route forecast: don't preempt a harvest already planned."""
    step, pid = int(obs['step']), int(obs['player'])
    farm = obs['farms'][pid]
    positions = [list(farm['farmer'])] + [list(x) for x in farm['hands']]
    route = _IMPL.chassis.players[pid]['route']
    for t in range(step, (step//24+1)*24):
        a = action if t == step else _IMPL.chassis.routes[2 if t >= 648 else route][t]
        commands = [a.get('farmer') or ['PASS'], *(a.get('hands') or [])]
        for i, cmd in enumerate(commands[:len(positions)]):
            if not cmd:
                continue
            if cmd[0] == 'HARVEST' and tuple(positions[i]) == target:
                return True
            if cmd[0] in MOVES:
                dx, dy = MOVES[cmd[0]]
                positions[i] = [max(0,min(9,positions[i][0]+dx)), max(0,min(9,positions[i][1]+dy))]
        for order in a.get('market', []):
            if order and order[0] == 'HIRE':
                access = ((4,4),(5,4),(4,5),(5,5))
                positions.append(list(min(access,key=lambda p:(sum(tuple(q)==p for q in positions),access.index(p)))))
    return False


def _g6_apply(obs, action):
    step, pid = int(obs['step']), int(obs['player'])
    day, hour = divmod(step, 24)
    if day < 6 or day >= 29 or hour == 23:
        return action
    farm, private = obs['farms'][pid], obs['private']
    positions = [farm['farmer'], *farm['hands']]
    commands = [list(action.get('farmer') or ['PASS']), *[list(x) for x in action.get('hands', [])]]
    stock = sum(private['shed'].values()) + sum(sum(i.values()) for i in private['inventories'])
    selected = set()
    for actor, cmd in enumerate(commands[:len(positions)]):
        if cmd != ['COLLECT_FERTILIZER']:
            continue
        x,y = positions[actor]
        tile = farm['tiles'][y][x]
        if not isinstance(tile,dict) or tile.get('animal') != 'GOOSE' or (x,y) in selected:
            continue
        held = int(tile.get('yield_units',0))
        # Only an already-fed, mature goose with a full nest. Feeding and care
        # remain the parent's responsibility; this choice adds no feed costs.
        if held < 4 or not tile.get('fed_today') or day+1-tile['placed_day'] < 4:
            continue
        if stock + held - 1 > 90:
            continue
        if _g6_harvest_later_today(obs,action,(x,y)):
            continue
        saved = min(held, 1+int(tile.get('pending_care_bonus',0)))
        inv = obs['market']['inventory']
        params = obs['market'].get('params')
        # Stress the incremental egg sale with 12 rival units; price fertilizer
        # at its replacement cost. The forecast uses currently public data only.
        egg_value = sum(_r37_market_price('EGG',inv['EGG']+12+j,params) for j in range(saved))
        fertilizer_value = _r37_market_price('FERTILIZER',inv['FERTILIZER']-1,params)
        if egg_value <= 1.25*fertilizer_value:
            continue
        commands[actor] = ['HARVEST']
        selected.add((x,y))
        stock += held-1
        _G6_STATS['changes'] += 1
        _G6_STATS['predicted_saved_units'] += saved
    if not selected:
        return action
    return dict(action,farmer=commands[0],hands=commands[1:])


globals().pop('agent',None)
def agent(observation,configuration=None):
    if int(observation.get('step',0)) == 0:
        _G6_STATS.update(changes=0,predicted_saved_units=0,errors=0)
    action = _G6_PARENT(observation,configuration)
    standard = configuration is None or all(configuration.get(k,v)==v for k,v in [('boardSize',10),('turnsPerDay',24),('shedCapacity',100)])
    if standard:
        try:
            return _g6_apply(observation,action)
        except Exception:
            _G6_STATS['errors'] += 1
    return action
