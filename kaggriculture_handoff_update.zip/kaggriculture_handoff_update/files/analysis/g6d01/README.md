# G6D01 — frozen diagnosis and pilot

2026-09-19。次の方策を設計するための証拠。**未提出・未昇格**。
次の仕様は [research handoff](../../docs/g6_research_handoff_2026-09-19.md)。

## 最初に読むファイル

- [report.md](report.md): 会話で渡した診断報告の原文。ファイル名・同梱物の記述は元のZIP構成を指す。
- [pilot_summary.json](pilot_summary.json): 96ゲーム/48対比較の集計。
- [pilot_results.jsonl](pilot_results.jsonl): 全ゲーム結果。再判断する相手と対戦、自分のprivateのみ提供。
- [live_summary.json](live_summary.json): 3ライブ試合の会計・生産集計。巨大なイベント列とscratch絶対パスだけを省いたもの。
- [action_parity.json](action_parity.json): canonical referenceと全2,157手の一致。
- `timing_*.json`: 未来情報を使い相手行動を固定した診断。実行可能な方策の性能ではない。
- [provenance.json](provenance.json): **元の研究キット**のファイルhashとソース出典。repo全体のmanifestではない。

## 再現用runtime

Python 3.12、標準ライブラリのみ。repo rootから実行:

```bash
python analysis/g6d01/prepare_workspace.py
```

既存repo内のTetsu/Aurax/frontier原本をhashで検証し、公式処理・初期状態・分析コードを
`analysis/g6d01/runtime/` に用意する。`harvest_overlay.py` をTetsuへ連結し、評価済み候補とbytes一致を確認する。
ソースが後日変わっていたら停止する。期待hashを変更して通すのではなく、元のcommitから別のcheckoutを用意する。

今回の96試合を再実行する必要がある場合のみ:

```bash
python analysis/g6d01/runtime/evaluate_candidate.py --workers 4 --out analysis/g6d01/runtime/recheck_results.jsonl
```

`panel_initial_states.json` は元の80リプレイ集から重複を除いて結果非依存で選んだ8シード。
旧キットの52MBのarchiveがなくても、この固定パネルは実行できる。
一方、この8シードは後続候補の未使用確認データにはならない。

## 原リプレイ

3原リプレイと完全イベントledgerは、会話で保存した `kaggriculture_g6_research_kit.zip` にある。
100MB近い展開済みJSONをGitへ重複登録していない。
ZIPのSHA-256: `33beb15a7eb24b13655445ce43316bf4c80a23f4e544c12230c7e117bfacfb4a`。
必要なときだけZIPを取得して展開し、例えば次のように実行する（パスは実際の展開先にする）:

```bash
python analysis/g6d01/runtime/analyze_replays.py /path/to/kaggriculture_g6_research_kit/replays --out analysis/g6d01/runtime/recheck_ledger
python analysis/g6d01/runtime/verify_reference.py /path/to/kaggriculture_g6_research_kit/replays/110751332.json /path/to/kaggriculture_g6_research_kit/replays/110748781.json /path/to/kaggriculture_g6_research_kit/replays/110787285.json --out analysis/g6d01/runtime/recheck_parity.json
```

原リプレイが手元にないことだけで、既存結果の読解やP1の設計を止めない。

## 重要な限界

- live診断3試合は全母集団の無作為標本ではない。Alperenは未診断。
- G6D01のW/D/L改善はTetsu同型の引き分け解消。残る2相手は基準も全勝。
- 相手コードは同系統を含む。seedと席の相関を無視しない。
- 公式処理を使っていてもKaggle本番サンドボックスの実行時間制限の測定とは別。
- 連続再現によりinventory辞書の挿入順を保持する。記録JSONを毎turn読み直さない。
- 診断コードが持つ相手private/未来行動を、新candidateへ渡さない。

[公式ソース（固定commit）](https://github.com/Kaggle/kaggle-environments/blob/28b6d8af3ce73926b3d0fda1410c1ddd8384ab8c/kaggle_environments/envs/kaggriculture/kaggriculture.py)。
公式処理のライセンスは `LICENSE.kaggle-environments.txt`、各公開方策の帰属表示は原本に保持。
新しい分析コード・overlay・prepareスクリプトはApache-2.0で提供する。
