#!/usr/bin/env python3
"""Privileged, fixed-opponent timing diagnostic; NOT an executable agent or win test.

Within nonoverlapping 12-turn windows, shift recorded cash-product sales by
one or two turns. Accept only improvements that leave exactly the same physical
state, both private inventories, market and town at the window boundary.
The search sees future recorded actions of BOTH players, so it only measures
recoverable timing differences under a frozen response. It is not a global bound.
"""
import argparse
import copy
import json
from pathlib import Path
from analyze_replays import Attr, attr, load_official

CASH = ('CARROT', 'TOMATO', 'STRAWBERRY', 'MELON', 'EGG', 'MILK', 'WOOL')


def initial(replay):
    observations = [attr(copy.deepcopy(s['observation'])) for s in replay['steps'][0]]
    for key in ('farms', 'market', 'town'):
        observations[1][key] = observations[0][key]
    return [Attr(observation=o, action=None, status='ACTIVE', reward=0) for o in observations]


def run(game, env, start, actions, start_step):
    state = copy.deepcopy(start)
    for off, pair in enumerate(actions):
        for pid in range(2):
            state[pid].observation.step = start_step + off
            state[pid].action = pair[pid]
        game.interpreter(state, env)
    return state


def boundary(state):
    obs = state[0].observation
    farms = copy.deepcopy(obs.farms)
    for f in farms:
        del f['money']
    return (farms, obs.market, obs.town, [s.observation.private for s in state])


def margin(state, pid):
    f = state[0].observation.farms
    return f[pid]['money'] - f[1-pid]['money']


def shifted(actions, pid, items, offset):
    result = copy.deepcopy(actions)
    moved = []
    for t, pair in enumerate(actions):
        for i, order in enumerate(pair[pid].get('market', [])):
            if len(order) >= 3 and order[0] == 'SELL' and order[1] in items:
                target = t + offset
                if not 0 <= target < len(actions):
                    return None
                moved.append((target, order))
                result[t][pid]['market'][i] = []
    if not moved:
        return None
    for t, order in moved:
        market = result[t][pid].setdefault('market', [])
        # Keep all purchase/hire ordering intact; use only all-SELL turns.
        if any(o and o[0] != 'SELL' for o in market):
            return None
        hit = next((o for o in market if o and o[:2] == order[:2]), None)
        if hit is not None:
            hit[2] += order[2]
        elif [] in market:
            market[market.index([])] = list(order)
        elif len(market) < 10:
            market.append(list(order))
        else:
            return None
    return result


def diagnose(path, window=12):
    replay = json.loads(Path(path).read_text())
    pid = replay['info']['TeamNames'].index('masa0219')
    game = load_official()
    env = Attr(configuration=attr(replay['configuration']), info=attr(replay['info']), done=False)
    all_actions = [[s['action'] for s in row] for row in replay['steps'][1:]]
    baseline = run(game, env, initial(replay), all_actions, 0)
    assert baseline[0].observation.farms == replay['steps'][-1][0]['observation']['farms']
    assert [s.observation.private for s in baseline] == [s['observation']['private'] for s in replay['steps'][-1]]
    state = initial(replay)
    changes = []
    evaluations = 0
    for start in range(0, len(all_actions), window):
        actions = all_actions[start:start+window]
        base = run(game, env, state, actions, start)
        signature = boundary(base)
        best, best_actions = base, actions
        selected = []
        # Frozen schedule search; no tuning based on the result of another episode.
        if start >= 144:
            for item in CASH:
                item_best, item_actions, item_offset = best, best_actions, None
                for offset in (-2, -1, 1, 2):
                    proposed = shifted(best_actions, pid, (item,), offset)
                    if proposed is None:
                        continue
                    candidate = run(game, env, state, proposed, start)
                    evaluations += 1
                    if margin(candidate, pid) > margin(item_best, pid) and boundary(candidate) == signature:
                        item_best, item_actions, item_offset = candidate, proposed, offset
                if item_offset is not None:
                    selected.append({'item': item, 'offset': item_offset,
                                     'margin_gain': margin(item_best, pid)-margin(best, pid)})
                    best, best_actions = item_best, item_actions
        if selected:
            changes.append({'start_step': start, 'gain': margin(best,pid)-margin(base,pid), 'changes': selected})
        state = best
    assert boundary(state) == boundary(baseline)
    return {'episode': replay['info']['EpisodeId'], 'teams': replay['info']['TeamNames'],
            'window': window, 'evaluations': evaluations,
            'baseline_margin': margin(baseline,pid), 'frozen_response_margin': margin(state,pid),
            'margin_gain': margin(state,pid)-margin(baseline,pid),
            'physical_and_stock_boundary_equal': True, 'changes': changes,
            'warning': 'Uses future opponent actions. Fixed-response diagnostic, not reactive play, not a rating estimate.'}


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('input')
    p.add_argument('--out', type=Path, required=True)
    args = p.parse_args()
    result = diagnose(args.input)
    args.out.write_text(json.dumps(result, indent=2))
    print(json.dumps({k:v for k,v in result.items() if k != 'changes'}), flush=True)
