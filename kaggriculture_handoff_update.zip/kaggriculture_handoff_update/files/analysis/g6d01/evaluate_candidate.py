#!/usr/bin/env python3
"""Paired full games: reactive agents, identical seeds, both seats, frozen panel.

Each policy only receives its own private observation. Opponents act again after
every state change; no recorded opponent actions or hidden future shops are used.
This small public-policy panel is a local pilot, not a live-population estimator.
"""
import argparse
import concurrent.futures
import copy
import hashlib
import importlib.util
import json
import time
import zipfile
from pathlib import Path
from analyze_replays import Attr, Auditor, attr, load_official
from timing_diagnostic import initial

ROOT = Path(__file__).resolve().parent


def load_policy(path):
    spec = importlib.util.spec_from_file_location('policy_'+path.stem,path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def play(job):
    panel, opponent, seat, candidate = job
    own_path = ROOT/('g6d01_candidate.py' if candidate else 'tetsu_reference.py')
    ours, theirs = load_policy(own_path), load_policy(ROOT/f'{opponent}_reference.py')
    policies = [ours, theirs] if seat == 0 else [theirs, ours]
    game = load_official()
    env = Attr(configuration=attr(panel['configuration']),info=attr(panel['info']),done=False)
    state = initial(panel)
    audit = Auditor(game)
    audit.install()
    maxima = [0.0,0.0]
    try:
        for step in range(719):
            audit.step = step
            audit.identities = {id(f):i for i,f in enumerate(state[0].observation.farms)}
            audit.private_ids = {id(s.observation.private):i for i,s in enumerate(state)}
            for pid in range(2):
                state[pid].observation.step = step
                start = time.perf_counter()
                state[pid].action = policies[pid].agent(copy.deepcopy(state[pid].observation),env.configuration)
                maxima[pid] = max(maxima[pid],time.perf_counter()-start)
            game.interpreter(state,env)
    finally:
        audit.uninstall()
    farms = state[0].observation.farms
    return {'episode_seed_source':panel['info']['EpisodeId'],'seed':panel['info']['seed'],
            'split':panel['split'],'opponent':opponent,'seat':seat,'candidate':candidate,
            'own_money':farms[seat]['money'],'opponent_money':farms[1-seat]['money'],
            'margin':farms[seat]['money']-farms[1-seat]['money'],
            'own_harvest':dict(audit.players[seat]['harvest']),
            'own_overflow':dict(audit.players[seat]['overflow']),
            'own_used_inputs':dict(audit.players[seat]['used_inputs']),
            'own_transactions':dict(audit.players[seat]['transactions']),
            'candidate_stats':getattr(ours,'_G6_STATS',{}),'max_call_seconds':maxima,
            'own_ending_stock':state[seat].observation.private}


def make_panel(archive, output):
    # Predeclared deterministic selection independent of policies' scores.
    with zipfile.ZipFile(archive) as z:
        names = [n for n in z.namelist() if '/replays/' in n and n.endswith('-replay.json')]
        names.sort(key=lambda n:hashlib.sha256(n.split('/')[-1].encode()).hexdigest())
        selected, seen = [], set()
        for name in names:
            if name.split('/')[-1] in seen:
                continue
            seen.add(name.split('/')[-1])
            r = json.loads(z.read(name))
            if r['info']['EpisodeId'] in (110751332,110748781,110787285):
                continue
            selected.append({'info':r['info'],'configuration':r['configuration'],
                             'steps':[r['steps'][0]],'split':'development' if len(selected)<4 else 'heldout',
                             'archive_member':name})
            if len(selected)==8:
                break
    assert len(selected)==8
    output.write_text(json.dumps(selected,indent=2))
    return selected


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--archive',type=Path)
    p.add_argument('--panel',type=Path,default=ROOT/'panel_initial_states.json')
    p.add_argument('--out',type=Path,default=ROOT/'pilot_results.jsonl')
    p.add_argument('--workers',type=int,default=4)
    p.add_argument('--smoke',action='store_true')
    args = p.parse_args()
    panel = json.loads(args.panel.read_text()) if args.panel.exists() else make_panel(args.archive,args.panel)
    jobs = [(r,o,s,c) for r in panel for o in ('tetsu','aurax','frontier') for s in (0,1) for c in (False,True)]
    if args.smoke:
        jobs = jobs[:2]
    with args.out.open('w') as out, concurrent.futures.ProcessPoolExecutor(max_workers=args.workers) as pool:
        for index,result in enumerate(pool.map(play,jobs)):
            out.write(json.dumps(result)+'\n');out.flush()
            print(json.dumps({'completed':index+1,'total':len(jobs),'seed':result['seed'],
                              'opponent':result['opponent'],'seat':result['seat'],
                              'candidate':result['candidate'],'margin':result['margin'],
                              'stats':result['candidate_stats']}),flush=True)
