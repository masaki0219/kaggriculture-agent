#!/usr/bin/env python3
"""Audit realized economics by replaying a whole game with official game code.

The action on recorded row k produced observation k from observation k-1.
Every reconstructed transition must exactly match farms, privates, market, town.
Carry simulated inventory insertion order forward; replay JSON sorts its keys.
No strategy verdict or ledger from a mismatching episode is accepted.
Python standard library only. Vendored official source stays unmodified.
"""
import argparse
import collections
import copy
import csv
import hashlib
import importlib.util
import json
import sys
import types
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent


class Attr(dict):
    def __getattr__(self, key):
        try:
            return self[key]
        except KeyError as exc:
            raise AttributeError(key) from exc

    __setattr__ = dict.__setitem__


def attr(value):
    if isinstance(value, dict):
        return Attr({k: attr(v) for k, v in value.items()})
    if isinstance(value, list):
        return [attr(v) for v in value]
    return value


def load_official():
    # _initialize is never used: each transition begins at a recorded state.
    # Fail explicitly if a future change accidentally invokes initialization.
    stub = types.ModuleType('kaggle_environments.utils')

    def no_initialization(*args, **kwargs):
        raise RuntimeError('Replay auditing must not initialize a new game')

    stub.resolve_episode_seed = no_initialization
    sys.modules.setdefault('kaggle_environments', types.ModuleType('kaggle_environments'))
    sys.modules.setdefault('kaggle_environments.utils', stub)
    spec = importlib.util.spec_from_file_location('official_kaggriculture', ROOT / 'official_kaggriculture.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def stock(private):
    out = collections.Counter(private['shed'])
    for inventory in private['inventories']:
        out.update(inventory)
    return out


def plain(value):
    if isinstance(value, dict):
        return {k: plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(v) for v in value]
    return value


def first_diff(actual, expected, path=''):
    if isinstance(actual, dict) and isinstance(expected, dict):
        if actual.keys() != expected.keys():
            return {'path': path, 'actual_keys': sorted(actual), 'expected_keys': sorted(expected)}
        for key in actual:
            result = first_diff(actual[key], expected[key], path + '/' + str(key))
            if result:
                return result
    elif isinstance(actual, list) and isinstance(expected, list):
        if len(actual) != len(expected):
            return {'path': path, 'actual_length': len(actual), 'expected_length': len(expected)}
        for i, (a, b) in enumerate(zip(actual, expected)):
            result = first_diff(a, b, path + '/' + str(i))
            if result:
                return result
    elif actual != expected:
        return {'path': path, 'actual': actual, 'expected': expected}
    return None


class Auditor:
    def __init__(self, game):
        self.game = game
        self.players = []
        for _ in range(2):
            self.players.append({
                'transactions': collections.defaultdict(lambda: {'qty': 0, 'coins': 0}),
                'harvest': collections.Counter(), 'collected_fertilizer': 0,
                'planted': collections.Counter(), 'animals_placed': collections.Counter(),
                'requests': collections.Counter(), 'effective': collections.Counter(),
                'overflow': collections.Counter(), 'used_inputs': collections.Counter(),
                'animal_capacity_losses': collections.Counter(),
                'daily': collections.defaultdict(lambda: {'revenue': 0, 'spending': 0, 'harvest_units': 0}),
                'land_steps': [], 'checkpoints': [],
                'sale_events': [], 'unit_events': [], 'animal_work': [],
            })
        self.step = 0
        self.identities = {}
        self.original = {}

    def player(self, farm):
        return self.identities[id(farm)]

    def install(self):
        g = self.game
        for name in ['_commit_unit', '_do_hire', '_do_buy_land', '_apply_unit_action', '_drop_inventories_to_shed', '_daily_refresh_animals']:
            self.original[name] = getattr(g, name)

        def commit(op, item, price, farm, private, market, shed_capacity=100):
            ok = self.original['_commit_unit'](op, item, price, farm, private, market, shed_capacity)
            if ok:
                p = self.players[self.player(farm)]
                t = p['transactions'][op + ':' + item]
                t['qty'] += 1
                t['coins'] += price
                p['daily'][self.step // 24]['revenue' if op == 'SELL' else 'spending'] += price
                if op == 'SELL':
                    p['sale_events'].append([self.step, item, price])
            return ok

        def hire(farm, private, board_size, mult=1):
            before = farm['money']
            self.original['_do_hire'](farm, private, board_size, mult)
            cost = before - farm['money']
            if cost:
                p = self.players[self.player(farm)]
                p['transactions']['HIRE']['qty'] += 1
                p['transactions']['HIRE']['coins'] += cost
                p['daily'][self.step // 24]['spending'] += cost

        def land(farm, board_size):
            before = farm['money']
            self.original['_do_buy_land'](farm, board_size)
            cost = before - farm['money']
            if cost:
                p = self.players[self.player(farm)]
                p['transactions']['BUY_LAND']['qty'] += 1
                p['transactions']['BUY_LAND']['coins'] += cost
                p['daily'][self.step // 24]['spending'] += cost
                p['land_steps'].append(self.step)

        def unit(farm, private, idx, action, board_size, day, turns_per_day, shed_capacity=100):
            op = action[0] if isinstance(action, list) and action else 'INVALID'
            p = self.players[self.player(farm)]
            before_stock = stock(private)
            before_seeds = dict(private['seeds'])
            position = g._farmer_position(farm, idx)
            before_pos = list(position) if position is not None else None
            before_tile = copy.deepcopy(farm['tiles'][position[1]][position[0]]) if position is not None else None
            before_inv = copy.deepcopy(private['inventories'])
            self.original['_apply_unit_action'](farm, private, idx, action, board_size, day, turns_per_day, shed_capacity)
            after_stock = stock(private)
            after_pos = g._farmer_position(farm, idx)
            after_tile = farm['tiles'][before_pos[1]][before_pos[0]] if before_pos is not None else None
            changed = (before_pos != (list(after_pos) if after_pos is not None else None)
                       or before_tile != after_tile or before_inv != private['inventories']
                       or before_seeds != private['seeds'])
            if changed:
                p['effective'][op] += 1
            if isinstance(before_tile, dict) and before_tile.get('animal') and op in ('FEED','CARE','HARVEST'):
                p['animal_work'].append({'step': self.step, 'actor': idx,
                    'op': op, 'animal': before_tile['animal'], 'position': before_pos,
                    'changed': changed, 'before': before_tile, 'after': copy.deepcopy(after_tile),
                    'wheat_used': max(0, before_stock['WHEAT']-after_stock['WHEAT'])})
            if op == 'HARVEST':
                for item, amount in (after_stock - before_stock).items():
                    p['harvest'][item] += amount
                    p['daily'][self.step // 24]['harvest_units'] += amount
                    p['unit_events'].append([self.step, 'HARVEST', item, amount])
            elif op == 'COLLECT_FERTILIZER':
                p['collected_fertilizer'] += max(0, after_stock['FERTILIZER'] - before_stock['FERTILIZER'])
            elif op == 'PLANT':
                for item, n in before_seeds.items():
                    count = n - private['seeds'].get(item, 0)
                    if count > 0:
                        p['planted'][item] += count
            elif op == 'PLACE' and changed and len(action) > 1 and action[1] in g.ANIMALS:
                if isinstance(after_tile, dict) and after_tile.get('animal') == action[1] and before_tile != after_tile:
                    p['animals_placed'][action[1]] += 1
            elif op == 'DROP':
                p['overflow'].update(before_stock - after_stock)
            elif op in ('FEED', 'FERTILIZE'):
                p['used_inputs'].update(before_stock - after_stock)

        def drop_all(private, capacity):
            before = stock(private)
            self.original['_drop_inventories_to_shed'](private, capacity)
            pid = self.private_ids[id(private)]
            self.players[pid]['overflow'].update(before - stock(private))

        def refresh_animals(farm, day):
            p = self.players[self.player(farm)]
            for row in farm['tiles']:
                for tile in row:
                    if not isinstance(tile,dict) or not tile.get('animal'):
                        continue
                    if not tile['fed_today'] and tile['consecutive_unfed'] >= 1:
                        continue  # Escapes before producing; this is not a capacity loss.
                    animal = g.ANIMALS[tile['animal']]
                    age = day+1-tile['placed_day']-animal['first_yield_day']
                    if age >= 0 and age % animal['interval'] == 0:
                        amount = 1+(tile.get('pending_care_bonus',0) if tile['fed_today'] else 0)
                        lost = max(0,tile['yield_units']+amount-animal['max_held'])
                        p['animal_capacity_losses'][animal['product']] += lost
            self.original['_daily_refresh_animals'](farm,day)

        g._commit_unit, g._do_hire, g._do_buy_land = commit, hire, land
        g._apply_unit_action, g._drop_inventories_to_shed = unit, drop_all
        g._daily_refresh_animals = refresh_animals

    def uninstall(self):
        for name, fn in self.original.items():
            setattr(self.game, name, fn)

    def analyze(self, replay):
        steps = replay['steps']
        env = Attr(configuration=attr(replay['configuration']), info=attr(replay['info']), done=False)
        self.install()
        mismatches = []
        try:
            obs = attr(copy.deepcopy(steps[0][0]['observation']))
            other = attr(copy.deepcopy(steps[0][1]['observation']))
            other.farms, other.market, other.town = obs.farms, obs.market, obs.town
            state = [Attr(observation=obs, action=None, status='ACTIVE', reward=0),
                     Attr(observation=other, action=None, status='ACTIVE', reward=0)]
            for k in range(1, len(steps)):
                # Carry the simulated state forward. Serialized replay dictionaries
                # sort keys and lose insertion order, which matters when cargo is
                # automatically deposited into a nearly full shed at day end.
                obs.step = k - 1
                other.step = k - 1
                self.step = obs.get('step', k-1)
                for pid in range(2):
                    state[pid].action = steps[k][pid]['action']
                self.identities = {id(f): i for i, f in enumerate(obs.farms)}
                self.private_ids = {id(s.observation.private): i for i, s in enumerate(state)}
                for pid in range(2):
                    action = state[pid].action or {}
                    for a in [action.get('farmer') or ['PASS'], *(action.get('hands') or [])]:
                        self.players[pid]['requests'][a[0] if a else 'INVALID'] += 1
                self.game.interpreter(state, env)
                expected = steps[k][0]['observation']
                for key in ['farms', 'market', 'town']:
                    diff = first_diff(plain(obs[key]), expected[key], key)
                    if diff:
                        mismatches.append({'row': k, **diff})
                for pid in range(2):
                    diff = first_diff(plain(state[pid].observation.private), steps[k][pid]['observation']['private'], f'private/{pid}')
                    if diff:
                        mismatches.append({'row': k, **diff})
                if mismatches:
                    break
                if k in (24, 72, 144, 216, 288, 360, 504, 648, 719):
                    for pid in range(2):
                        farm = obs.farms[pid]
                        p = self.players[pid]
                        trans = p['transactions']
                        p['checkpoints'].append({'row': k, 'money': farm.money,
                            'revenue': sum(v['coins'] for key, v in trans.items() if key.startswith('SELL:')),
                            'spending': sum(v['coins'] for key, v in trans.items() if not key.startswith('SELL:')),
                            'harvest': dict(p['harvest']),
                            'crops': dict(collections.Counter(t['crop'] for row in farm.tiles for t in row if isinstance(t,dict) and t.get('crop'))),
                            'animals': dict(collections.Counter(t['animal'] for row in farm.tiles for t in row if isinstance(t,dict) and t.get('animal'))),
                            'land': len(farm.unlocked_quadrants)})
        finally:
            self.uninstall()
        info = replay['info']
        result = {'episode_id': info.get('EpisodeId', replay.get('id')), 'seed': info.get('seed'),
                  'teams': info.get('TeamNames'), 'validated': not mismatches,
                  'transitions_checked': k, 'mismatches': mismatches,
                  'shops': steps[-1][0]['observation']['town']['unlocked_shops']}
        if mismatches:
            return result
        result['players'] = []
        for pid, p in enumerate(self.players):
            transactions = p['transactions']
            revenue = sum(v['coins'] for key,v in transactions.items() if key.startswith('SELL:'))
            spending = sum(v['coins'] for key,v in transactions.items() if not key.startswith('SELL:'))
            initial = steps[0][0]['observation']['farms'][pid]['money']
            final = steps[-1][0]['observation']['farms'][pid]['money']
            ending = dict(stock(steps[-1][pid]['observation']['private']))
            assert initial + revenue - spending == final, (initial, revenue, spending, final)
            balances = {}
            for item in self.game.PRODUCTS:
                opening = stock(steps[0][pid]['observation']['private'])[item]
                incoming = p['harvest'][item] + transactions.get('BUY_PRODUCT:'+item,{}).get('qty',0)
                if item == 'FERTILIZER':
                    incoming += p['collected_fertilizer']
                outgoing = transactions.get('SELL:'+item,{}).get('qty',0) + p['used_inputs'][item] + p['overflow'][item]
                residual = opening + incoming - outgoing - ending.get(item,0)
                balances[item] = residual
            assert all(v == 0 for v in balances.values()), balances
            result['players'].append(plain({**p, 'team': result['teams'][pid], 'seat': pid,
                    'initial': initial, 'final': final, 'revenue': revenue, 'spending': spending,
                    'ending_stock': ending, 'inventory_balance_residuals': balances}))
        return result


def input_replays(paths):
    seen = set()
    for entry in paths:
        path = Path(entry)
        files = sorted(path.rglob('*.json')) if path.is_dir() else [path]
        for file in files:
            if file.suffix == '.zip':
                with zipfile.ZipFile(file) as archive:
                    for name in archive.namelist():
                        if name.endswith('.json') and 'episode-' in name:
                            d = json.loads(archive.read(name))
                            key = d.get('info',{}).get('EpisodeId', name)
                            if key not in seen:
                                seen.add(key)
                                yield str(file) + ':' + name, d
            else:
                d = json.loads(file.read_text())
                if not isinstance(d,dict) or 'steps' not in d:
                    continue
                key = d.get('info',{}).get('EpisodeId', str(file))
                if key not in seen:
                    seen.add(key)
                    yield str(file), d


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('inputs', nargs='+')
    parser.add_argument('--team', default='masa0219')
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--limit', type=int)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    game = load_official()
    results = []
    for path, replay in input_replays(args.inputs):
        if args.team and args.team not in replay.get('info',{}).get('TeamNames',[]):
            continue
        r = Auditor(game).analyze(replay)
        r['source'] = path
        results.append(r)
        print(json.dumps({'episode': r['episode_id'], 'validated': r['validated'], 'mismatches': r['mismatches'],
                          'finals': [p['final'] for p in r.get('players',[])]}), flush=True)
        if args.limit and len(results) >= args.limit:
            break
    artifact = {'official_source_sha256': hashlib.sha256((ROOT/'official_kaggriculture.py').read_bytes()).hexdigest(),
                'alignment': 'action[k] maps observation[k-1] to observation[k]', 'episodes': results}
    (args.out/'ledger.json').write_text(json.dumps(artifact, ensure_ascii=False, indent=2))
    rows = []
    for r in results:
        for p in r.get('players',[]):
            rows.append({'episode': r['episode_id'], 'team': p['team'], 'seat': p['seat'], 'money': p['final'],
                         'revenue': p['revenue'], 'spending': p['spending'],
                         'harvest_units': sum(p['harvest'].values()), 'overflow_units': sum(p['overflow'].values()),
                         'ending_units': sum(p['ending_stock'].values())})
    if rows:
        with (args.out/'summary.csv').open('w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0]))
            writer.writeheader();writer.writerows(rows)
    if not results or any(not r['validated'] for r in results):
        raise SystemExit('No accepted complete dataset: inspect ledger.json before drawing conclusions')


if __name__ == '__main__':
    main()
