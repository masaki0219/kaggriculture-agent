#!/usr/bin/env python3
"""Rebuild the frozen G6D01 runtime from repository sources, checking hashes.

Run from repository root; no network, credentials, third-party packages or git
mutations. The default output directory is git-ignored. Results of later runs
should use new filenames rather than replacing the checked-in experiment.
"""
import argparse
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
SOURCES = {
    'tetsu_reference.py': 'candidates/2026-09-19_public/tetsutani_demand-preserving-turn-sale-timing/main.py',
    'aurax_reference.py': 'artifacts/bundles/current/public_agents/elite/aurax7_v7_current/raw/_extract_submission_tar/main.py',
    'frontier_reference.py': 'artifacts/bundles/current/public_agents/elite/prvsiyan_frontier/raw/_extract_submission_tar/main.py',
}
COPY = ('analyze_replays.py', 'verify_reference.py', 'timing_diagnostic.py',
        'evaluate_candidate.py', 'official_kaggriculture.py', 'kaggriculture.json',
        'panel_initial_states.json', 'LICENSE.kaggle-environments.txt', 'harvest_overlay.py')


def digest(data):
    return hashlib.sha256(data).hexdigest()


def matched_source(path, expected):
    data = path.read_bytes()
    # Connector materialization may have added one final newline. Do not accept
    # semantic or whitespace changes elsewhere, even if a source still imports.
    for candidate in (data, data.rstrip(b'\n') + b'\n', data.rstrip(b'\n') + b'\n\n', data.rstrip(b'\n')):
        if digest(candidate) == expected:
            return candidate
    raise ValueError(f'Pinned source mismatch: {path}; retrieve the original reference commit, do not update its expected hash')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, default=ROOT/'runtime')
    args = parser.parse_args()
    out = args.out.resolve()
    manifest = json.loads((ROOT/'provenance.json').read_text())['files']
    # Validate every input before writing any output.
    files = {n: matched_source(REPO/p,manifest[n]['sha256']) for n,p in SOURCES.items()}
    for name in COPY:
        data = (ROOT/name).read_bytes()
        if digest(data) != manifest[name]['sha256']:
            raise ValueError(f'Frozen diagnostic input changed: {name}')
        files[name] = data
    candidate = files['tetsu_reference.py'] + b'\n\n' + files['harvest_overlay.py']
    if digest(candidate) != manifest['g6d01_candidate.py']['sha256']:
        raise ValueError('Candidate assembly differs from the evaluated bytes')
    files['g6d01_candidate.py'] = candidate
    if out == ROOT or out == REPO:
        raise ValueError('Use a separate runtime directory')
    for name,data in files.items():
        target = out/name
        if target.exists() and target.read_bytes() != data:
            raise ValueError(f'Existing different file: {target}; choose a new --out directory')
    out.mkdir(parents=True,exist_ok=True)
    for name,data in files.items():
        (out/name).write_bytes(data)
    print(json.dumps({'runtime':str(out),'verified_files':len(files),
                      'candidate_sha256':digest(candidate)},indent=2))


if __name__ == '__main__':
    main()
